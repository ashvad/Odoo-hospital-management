{
    'name': "COC-5",
    'depends': ['base'],
    'version': '1,0',
    'data': ['security/ir.model.access.csv',
             'views/selection.xml',
             'views/menus.xml'],
    'application': 'True',

}
